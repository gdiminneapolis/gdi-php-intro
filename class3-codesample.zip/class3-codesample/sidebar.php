<nav class="sidebar span3">
  <ul>
    <li><a href="#">Nav Link 1</a></li>
    <li><a href="#">Nav Link 2</a></li>
    <li><a href="#">Nav Link 3</a></li>
    <li><a href="#">Nav Link 4</a></li>
  </ul>
</nav>
