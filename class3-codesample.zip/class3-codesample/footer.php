</div>

<footer class="span12 break clear">
  <div class="container">
    <p>Sample PHP page | (888) 555-1234 | 123 Main St. Anytown, USA 01000 </p>
  </div>
</footer>
</body>
</html>
